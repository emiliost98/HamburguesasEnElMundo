//
//  ViewController.swift
//  Hamburguesas en el mundo
//
//  Created by Emilio Ceballos on 9/5/19.
//  Copyright © 2019 d. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
let paises = ColeccionDePaises()
let hamburguesas = ColeccionDeHamburguesas()
let colores = Colores()

    
    @IBOutlet weak var paisL: UILabel!
    @IBOutlet weak var hamburL: UILabel!
   
    
    @IBAction func dameHamb() {
        paisL.text = paises.paisAleat()
        hamburL.text = hamburguesas.hamburAleat()
        view.tintColor = colores.colorAleat()
        view.backgroundColor = view.tintColor
    }
}

